Social assets for use in Profile README.
