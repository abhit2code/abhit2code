Place for images used in my profile.
